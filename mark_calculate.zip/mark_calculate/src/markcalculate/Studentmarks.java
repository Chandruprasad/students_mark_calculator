package markcalculate;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Studentmarks {

	private JFrame frmMarkCalculator;
	private JTextField txtm1;
	private JTextField txtm2;
	private JTextField txtm3;
	private JTextField txtm4;
	private JTextField txtm5;
	private JTextField txtm6;
	private JTextField txttot;
	private JTextField txtavg;
	private JTextField txtg;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Studentmarks window = new Studentmarks();
					window.frmMarkCalculator.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public Studentmarks() {
		initialize();
	}

	
	private void initialize() {
		frmMarkCalculator = new JFrame();
		frmMarkCalculator.setTitle("mark calculator");
		frmMarkCalculator.setBounds(100, 100, 557, 488);
		frmMarkCalculator.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMarkCalculator.getContentPane().setLayout(null);
		
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(21, 11, 484, 427);
		frmMarkCalculator.getContentPane().add(panel);
		panel.setLayout(null);
		
		txtm1 = new JTextField();
		txtm1.setBounds(285, 70, 128, 20);
		panel.add(txtm1);
		txtm1.setColumns(10);
		
		JLabel firstsub = new JLabel("1st SUBJECT MARK");
		firstsub.setFont(new Font("Tahoma", Font.BOLD, 11));
		firstsub.setBounds(81, 73, 138, 14);
		panel.add(firstsub);
		
		JLabel secondsub = new JLabel("2nd SUBJECT MARK");
		secondsub.setFont(new Font("Tahoma", Font.BOLD, 11));
		secondsub.setBounds(81, 110, 138, 14);
		panel.add(secondsub);
		
		JLabel thirdsub = new JLabel("3rd SUBJECT MARK");
		thirdsub.setFont(new Font("Tahoma", Font.BOLD, 11));
		thirdsub.setBounds(81, 142, 138, 14);
		panel.add(thirdsub);
		
		JLabel forthsub = new JLabel("4th SUBJECT MARK");
		forthsub.setFont(new Font("Tahoma", Font.BOLD, 11));
		forthsub.setBounds(81, 176, 138, 14);
		panel.add(forthsub);
		
		JLabel fifthsub = new JLabel("5th SUBJECT MARK");
		fifthsub.setFont(new Font("Tahoma", Font.BOLD, 11));
		fifthsub.setBounds(81, 210, 138, 14);
		panel.add(fifthsub);
		
		JLabel sixthsub = new JLabel("6th SUBJECT MARK");
		sixthsub.setFont(new Font("Tahoma", Font.BOLD, 11));
		sixthsub.setBounds(81, 246, 138, 14);
		panel.add(sixthsub);
		
		txtm2 = new JTextField();
		txtm2.setColumns(10);
		txtm2.setBounds(285, 107, 128, 20);
		panel.add(txtm2);
		
		txtm3 = new JTextField();
		txtm3.setColumns(10);
		txtm3.setBounds(285, 139, 128, 20);
		panel.add(txtm3);
		
		txtm4 = new JTextField();
		txtm4.setColumns(10);
		txtm4.setBounds(285, 173, 128, 20);
		panel.add(txtm4);
		
		txtm5 = new JTextField();
		txtm5.setColumns(10);
		txtm5.setBounds(285, 207, 128, 20);
		panel.add(txtm5);
		
		txtm6 = new JTextField();
		txtm6.setColumns(10);
		txtm6.setBounds(285, 243, 128, 20);
		panel.add(txtm6);
		
		txttot = new JTextField();
		txttot.setColumns(10);
		txttot.setBounds(10, 313, 128, 20);
		panel.add(txttot);
		
		txtavg = new JTextField();
		txtavg.setColumns(10);
		txtavg.setBounds(176, 313, 128, 20);
		panel.add(txtavg);
		
		JLabel lbtot = new JLabel("TOTAL");
		lbtot.setFont(new Font("Tahoma", Font.BOLD, 11));
		lbtot.setBounds(44, 288, 80, 14);
		panel.add(lbtot);
		
		JLabel lbavg = new JLabel("AVERAGE");
		lbavg.setFont(new Font("Tahoma", Font.BOLD, 11));
		lbavg.setBounds(205, 288, 80, 14);
		panel.add(lbavg);
		
		JButton btnCalculate = new JButton("CALCULATE");
		btnCalculate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int m1=Integer.parseInt(txtm1.getText());
				int m2=Integer.parseInt(txtm2.getText());
				int m3=Integer.parseInt(txtm3.getText());
				int m4=Integer.parseInt(txtm4.getText());
				int m5=Integer.parseInt(txtm5.getText());
				int m6=Integer.parseInt(txtm6.getText());
				
				int tot= m1+m2+m3+m4+m5+m6;
				
				double avg = tot/6;
				
				txttot.setText(String.valueOf(tot));
				txtavg.setText(String.valueOf(avg));
				//txtg.setText(String.valueOf(grade));
				
				if(avg >= 90)
				{
					txtg.setText("A+");
					JOptionPane.showMessageDialog(btnCalculate,"congrates! Great your get A+ grade !");
				}
				else if(avg>=80)
				{
					txtg.setText("A");JOptionPane.showMessageDialog(btnCalculate,"Great your get A grade !");
				}
				else if(avg>=70)
				{
					txtg.setText("B");JOptionPane.showMessageDialog(btnCalculate,"Great your get B grade !");
				}
				else if(avg>=60)
				{
					txtg.setText("C");JOptionPane.showMessageDialog(btnCalculate,"Great your get C grade !");
				}
				else if(avg>=50)
				{
					txtg.setText("D");JOptionPane.showMessageDialog(btnCalculate," your get D grade !");
				}
				else
				{
					txtg.setText("F");JOptionPane.showMessageDialog(btnCalculate,"it's alright tryagain !");
				}
				
			}
		});
		btnCalculate.setBackground(Color.CYAN);
		btnCalculate.setBounds(176, 369, 114, 23);
		panel.add(btnCalculate);
		
		JLabel lbgrade = new JLabel("GRADE");
		lbgrade.setFont(new Font("Tahoma", Font.BOLD, 11));
		lbgrade.setBounds(394, 288, 80, 14);
		panel.add(lbgrade);
		
		txtg = new JTextField();
		txtg.setColumns(10);
		txtg.setBounds(346, 313, 128, 20);
		panel.add(txtg);
		
		JButton btnexit = new JButton("EXIT");
		btnexit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		btnexit.setBounds(348, 369, 89, 23);
		panel.add(btnexit);
		
		JButton btnReset = new JButton("RESET");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				txtm1.setText("");
				txtm2.setText("");
				txtm3.setText("");
				txtm4.setText("");
				txtm5.setText("");
				txtm6.setText("");
				txttot.setText("");
				txtavg.setText("");
				txtg.setText("");
				txtm1.requestFocus();
			}
		});
		btnReset.setBounds(35, 369, 89, 23);
		panel.add(btnReset);
		
		JLabel title = new JLabel("CALCULATE YOUR SCORE");
		title.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		title.setBounds(136, 16, 258, 27);
		panel.add(title);
	}
}
